# Analyzing-Networks-Project
Last assignment of the class Analyzing Networks.

Run instance_demo.py to produce the output for all tasks. rafs_instance.py is a dependency of this script.

Solutions folder contains the XML files with order assignments and routes for all tasks.
